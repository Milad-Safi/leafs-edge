import React, { useMemo } from "react";
import type { EdgeAreaRow } from "@/hooks/useTeamEdge";

type Mode = "shots" | "goals";

function safeNum(n: unknown) {
  const x = typeof n === "number" ? n : Number(n);
  // Round to the nearest whole number
  return Number.isFinite(x) ? Math.round(x) : 0;
}

function valueFor(row: EdgeAreaRow | undefined, mode: Mode) {
  if (!row) return 0;
  return mode === "shots" ? safeNum(row.sog) : safeNum(row.goals);
}

export default function OffensiveZoneHeatmap({
  areas,
  mode,
  height = 500,
}: {
  areas: EdgeAreaRow[];
  mode: Mode;
  height?: number;
}) {
  // 1. Data Mapping
  const byArea = useMemo(() => {
    const m = new Map<string, EdgeAreaRow>();
    for (const r of areas ?? []) m.set(r.area, r);
    return m;
  }, [areas]);

  const vals = useMemo(() => {
    const get = (name: string) => valueFor(byArea.get(name), mode);

    return {
      "L Corner": get("L Corner"),
      "Behind the Net": get("Behind the Net"),
      "R Corner": get("R Corner"),
      "Outside L": get("Outside L"),
      "L Net Side": get("L Net Side"),
      "Low Slot": get("Low Slot"),
      Crease: get("Crease"),
      "R Net Side": get("R Net Side"),
      "Outside R": get("Outside R"),
      "L Circle": get("L Circle"),
      "High Slot": get("High Slot"),
      "R Circle": get("R Circle"),
      "L Point": get("L Point"),
      "Center Point": get("Center Point"),
      "R Point": get("R Point"),
      "Offensive Neutral Zone": get("Offensive Neutral Zone"),
    };
  }, [byArea, mode]);

  const { maxArea, maxValue, unitLabel } = useMemo(() => {
    const unit = mode === "shots" ? "SOG" : "goals";
    let bestArea = "";
    let best = -1;

    for (const [k, v] of Object.entries(vals)) {
      if (v > best) {
        best = v;
        bestArea = k;
      }
    }
    return { maxArea: bestArea, maxValue: Math.max(0, best), unitLabel: unit };
  }, [vals, mode]);

  const COLORS = {
    CREASE: "#5ab5e3ff",
    PLAIN_WHITE: "#ffffff",
    STROKE: "#000000",
    NAVY: "#004161",
    RED: "rgba(210, 97, 97, 1)",
    GREEN: "rgba(6, 219, 10, 1)",
    BLACK: "rgba(0, 0, 0, 1)",
    BLUE_LINE: "#0033a0"
  };

  const lowSlotIsMax = maxArea === "Low Slot";

  return (
    <div style={{ width: "100%", position: "relative" }}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 204 214"
        width="100%"
        height={height}
        style={{
          display: "block",
          borderRadius: 16,
          background: COLORS.BLACK,
          border: `2px solid ${COLORS.STROKE}`,

          fontFamily: "Inter, system-ui, -apple-system, sans-serif",
          fontWeight: 500,
          letterSpacing: "0.1px",
        }}
      >
        {/* --- TOP ICE STRIPS --- */}
        <svg viewBox="0 0 50 30" width="50" height="30" x="13" y="3" fill={COLORS.PLAIN_WHITE}>
          <path d="M49.713 29.9225V0.19458C39.0746 0.871745 28.7801 4.22718 19.7861 9.94905C14.1774 13.5278 9.16226 17.9608 4.92212 23.0877C4.32491 23.8177 3.79406 24.4812 3.2632 25.2112C2.40709 26.3187 1.6097 27.4705 0.874357 28.6617C0.60893 29.1262 0.277146 29.5244 0.0117188 29.9889H49.713V29.9225Z" />
        </svg>

        <svg viewBox="0 0 76 30" width="76" height="30" x="64" y="3" fill={COLORS.PLAIN_WHITE}>
          <path d="M75.5538 -0.00463867H0.570312V29.9887H75.5538V-0.00463867Z" />
        </svg>

        <svg viewBox="0 0 50 30" width="50" height="30" x="141" y="3" fill={COLORS.PLAIN_WHITE}>
          <path d="M0.332031 29.9894H49.5314C49.2679 29.5331 48.9806 29.091 48.6705 28.665C47.9367 27.4763 47.1411 26.327 46.2867 25.2217C45.7719 24.4873 45.2194 23.78 44.6313 23.1028C40.4477 17.9899 35.4872 13.5657 29.9311 9.99175C21.0524 4.28415 10.8653 0.934027 0.332031 0.257812V29.9894Z" />
        </svg>

        <svg viewBox="0 0 57 113" width="57" height="113" x="2" y="33" fill={COLORS.PLAIN_WHITE}>
          <path d="M9.40101 1.57176C9.55325 1.27053 9.73045 0.982587 9.93075 0.710938H32.3784C32.4446 0.975807 32.5108 1.30689 32.577 1.57176C36.2857 14.6735 43.7983 26.3803 54.1638 35.2101C54.6935 35.6737 55.2895 36.1372 55.8854 36.6007C56.1413 36.7829 56.3846 36.982 56.6138 37.1967L26.9486 76.927L0.726569 112.022V33.8196C0.721648 22.4932 3.71446 11.3672 9.40101 1.57176Z" />
        </svg>

        {/* Center Wedges */}
        <svg viewBox="0 0 52 37" width="52" height="37" x="34" y="34" fill={COLORS.PLAIN_WHITE}>
          <path d="M0.931572 0.930176H51.8242L24.8811 36.3554C24.8811 36.3554 17.3968 31.366 10.4116 20.8881C3.42631 10.4102 0.931572 0.930176 0.931572 0.930176Z" />
        </svg>

        {/* infront of net  */}
        <svg viewBox="0 0 85 53" width="85" height="53" x="59" y="33" fill={COLORS.RED}>
          <path d="M57.7579 0.932373H28.8189L0.378906 38.3534C2.10057 39.6116 3.87154 42.345 10.3579 45.3387C16.8442 48.3324 33.8084 53.8208 46.781 52.8229C59.7537 51.825 69.2945 48.2524 75.72 44.3408C82.1454 40.4292 82.8163 39.8126 84.701 38.3534L57.7579 0.932373Z" />
        </svg>

        {/* right side net  */}
        <svg viewBox="0 0 52 37" width="52" height="37" x="117" y="33" fill={COLORS.PLAIN_WHITE}>
          <path d="M51.6466 0.930176H0.753906L27.6971 36.3554C27.6971 36.3554 35.1813 31.366 42.1665 20.8881C49.1518 10.4102 51.6466 0.930176 51.6466 0.930176Z" />
        </svg>

        {/* Remaining zones */}
        <svg viewBox="0 0 33 18" width="33" height="18" x="85" y="33" fill={COLORS.CREASE}>
          <path
            d="M1.89018 0.909912C1.83305 1.26 1.81087 1.61491 1.82396 1.96939V3.02887C2.08446 6.65021 3.71573 10.036 6.38546 12.4966C9.05519 14.9572 12.5626 16.3075 16.1931 16.2723C17.3087 16.2749 18.4206 16.1414 19.5039 15.875C22.4491 15.2211 25.1117 13.6517 27.1101 11.3916C29.1084 9.13151 30.3401 6.29681 30.6284 3.29374C30.6284 2.89643 30.6946 2.56535 30.6946 2.16804V1.96939C30.7036 1.61497 30.6814 1.26045 30.6284 0.909912"
            stroke={COLORS.STROKE}
            strokeWidth="2"
            strokeMiterlimit="10"
          />
        </svg>

        {/* right wall */}
        <svg viewBox="0 0 56 112" width="56" height="112" x="145" y="34" fill={COLORS.PLAIN_WHITE}>
          <path d="M47.2385 1.8369C47.1061 1.57203 46.9074 1.30716 46.775 0.976074H24.7247C24.6585 1.24094 24.5923 1.57203 24.526 1.8369C20.8929 14.8168 13.4966 26.4297 3.27034 35.2104C2.74061 35.6739 2.14465 36.1375 1.5487 36.601C1.28383 36.7996 1.08518 36.9983 0.820312 37.1969L29.9559 76.5962L55.7143 111.36V33.8198C55.7227 22.6026 52.801 11.5778 47.2385 1.8369Z" />
        </svg>

        {/* left slot */}
        <svg viewBox="0 0 55 64" width="55" height="64" x="27" y="72" fill={COLORS.RED}>
          <path d="M54.3228 11.6458L37.7023 62.6331L37.4374 63.4277C23.5318 58.7263 11.1492 50.4491 0.488281 40.9138L31.2793 0.190186C38.2132 5.35669 46.0181 9.23673 54.3228 11.6458Z" />
        </svg>

        {/* mid slot */}
        <svg viewBox="0 0 75 58" width="75" height="58" x="65" y="82" fill={COLORS.RED}>
          <path d="M74.7334 51.3679C62.8805 55.8045 49.1735 57.3937 35.7314 57.3937C23.7477 57.4086 11.8443 55.4396 0.503721 51.5666H0.4375L17.0581 0.645453C23.2847 2.40487 29.7245 3.29618 36.1949 3.29414C43.3121 3.29822 50.3889 2.22665 57.1858 0.115723L74.7334 51.3679Z" />
        </svg>

        {/* red slot */}
        <svg viewBox="0 0 52 63" width="52" height="63" x="122" y="70" fill={COLORS.RED}>
          <path d="M0.246094 11.8293L15.9465 61.8497L16.2124 62.7219C30.118 58.0205 41.2368 50.9193 51.8977 41.4503L21.1068 0.925293C14.182 6.07599 8.55463 9.49463 0.246094 11.8293Z" />
        </svg>

        <svg viewBox="0 0 64 69" width="64" height="69" x="2" y="114" fill={COLORS.PLAIN_WHITE}>
          <path d="M63.2888 21.6135L60.1104 31.4137L59.8456 32.1421L47.7419 68.5814L47.6095 68.9125H2.51622C1.65541 68.3166 0.860811 67.7206 0 67.1247V36.4661L22.1592 6.49746L22.2254 6.43124L26.7281 0.47168C31.7535 4.21383 38.9179 9.74545 42.9095 12.2402C46.9011 14.7349 56.8503 19.8388 63.2888 21.6135Z" />
        </svg>

        <svg viewBox="0 0 107 49" width="107" height="49" x="50" y="133" fill={COLORS.PLAIN_WHITE}>
          <path d="M106.178 48.6473L89.7131 0.223145C89.7131 0.223145 75.2436 7.20841 52.7909 7.20841C30.3383 7.20841 16.8667 1.71999 16.8667 1.71999L0.900391 48.6473H106.178Z" />
        </svg>

        <svg viewBox="0 0 64 69" width="64" height="69" x="138" y="113" fill={COLORS.PLAIN_WHITE}>
          <path d="M0.711205 21.6155L3.88959 31.4157L4.15445 32.144L16.2581 68.5834L16.3905 68.9145H61.4838C62.3446 68.3185 63.1392 67.7226 64 67.1266V36.468L41.8408 6.49941L41.7746 6.43319L37.2719 0.473633C32.2465 4.21578 25.0821 9.74741 21.0905 12.2421C17.0989 14.7369 7.14973 19.8408 0.711205 21.6155Z" />
        </svg>

        <svg viewBox="0 0 200 32" width="200" height="32" x="3" y="180" fill={COLORS.PLAIN_WHITE}>
          <path d="M199.578 0.846191V30.7102L0.0664062 31.0413V0.846191H199.578Z" />
        </svg>

        {/* --- BLACK OUTLINES --- */}
        <g stroke={COLORS.STROKE} strokeWidth="2" strokeMiterlimit="10" fill="none">
          <path d="M201.243 181.978H2.32703" />
          <path d="M2.06226 77.0239V212.041L201.574 211.71V147.612L201.243 147.214L174.756 111.788C174.663 111.896 174.551 111.986 174.425 112.053L172.637 113.642C169.399 116.471 165.994 119.102 162.44 121.522C161.712 121.985 160.983 122.515 160.321 122.979L158.136 124.369C157.407 124.833 156.679 125.23 155.951 125.694C155.222 126.091 154.494 126.554 153.766 126.952C152.044 127.879 150.322 128.806 148.534 129.667C148.269 129.799 148.071 129.865 147.806 129.998C147.409 130.196 147.011 130.395 146.548 130.594C145.753 130.991 144.959 131.322 144.164 131.653C142.972 132.183 141.846 132.646 140.655 133.11C138.712 133.722 139.674 133.589 139.21 133.722M139.463 134.368V134.434L144.628 150.393L154.825 181.647L154.891 181.846L154.957 181.978V182.045" />
          <path d="M2.06226 148.141L28.4163 112.781C39.233 122.483 51.8876 129.914 65.6299 134.633" />
          <path d="M50.3319 182.045L65.6282 134.633C89.5741 142.84 115.628 142.465 139.328 133.573" />
          <path d="M201.574 73.5144V147.612L174.69 111.788" />
          <path d="M65.6269 134.699C51.8845 129.98 39.2297 122.549 28.4129 112.848L59.2038 71.7267C71.3582 80.9416 86.1977 85.9192 101.45 85.8972C116.977 85.8948 132.066 80.7487 144.359 71.2632L174.753 111.854C164.445 121.315 151.805 128.293 138.711 133.223M65.6269 134.699L82.1811 83.381M65.6269 134.699C89.5726 142.906 115.012 142.115 138.711 133.223M138.711 133.223L123.103 83.3147" />
          <path d="M63.3829 33.9166H33.7177C33.7839 34.1814 33.8501 34.5125 33.9163 34.7774C37.7986 48.4321 45.7152 60.5955 56.6288 69.6739L58.4166 71.0645C58.6815 71.2631 58.8802 71.3955 59.145 71.5942L87.4198 33.8503H63.3829" />
          <path d="M140.323 33.9165H116.352L144.296 71.1968L145.091 70.6009C145.687 70.1374 146.283 69.6738 146.879 69.1441C157.498 60.1377 165.197 48.1742 168.995 34.7773C169.061 34.5125 169.127 34.1814 169.194 33.9165H140.323Z" />
          <path d="M174.695 111.788L144.302 71.1968L145.096 70.6009C145.692 70.1374 146.288 69.6738 146.884 69.1441C157.504 60.1377 165.203 48.1742 169.001 34.7773C169.067 34.5125 169.133 34.1814 169.199 33.9165H192.177C192.375 34.1814 192.508 34.5125 192.706 34.7773C198.528 44.7915 201.59 56.1703 201.579 67.7535V73.5144" />
          <path d="M11.3983 33.9164H63.3788V2.13208C51.9534 2.90187 40.9278 6.64555 31.3959 12.9917C25.7999 16.7484 20.7999 21.3243 16.5633 26.5663C15.9673 27.2947 15.3713 28.0893 14.8416 28.8176C13.9808 30.0096 13.12 31.2677 12.3254 32.5258L11.3983 33.9164Z" />
          <path d="M140.329 33.9166H192.177C191.912 33.4531 191.581 32.9896 191.316 32.5261C190.522 31.2679 189.661 30.0098 188.8 28.8179C188.204 28.0233 187.674 27.2949 187.012 26.5665C182.618 21.101 177.389 16.3633 171.517 12.5284C162.188 6.43841 151.446 2.85769 140.329 2.13232V33.9166Z" />
          <path d="M140.327 2.13219C139.467 2.06597 138.539 1.99976 137.679 1.99976H65.9642C65.1034 1.99976 64.2426 2.06597 63.3817 2.13219V33.9827H87.4852" />
          <path d="M2.06228 77.024V67.7535C2.05214 56.1703 5.1139 44.7915 10.9354 34.7773L11.4651 33.9165H33.7803C33.8465 34.1814 33.9127 34.5125 33.9789 34.7773C37.8613 48.4320 45.7779 60.5955 56.6914 69.6738L58.4793 71.0644C58.7441 71.2631 58.9428 71.3955 59.2077 71.5941L28.4167 112.715" />
        </g>

        <line
          x1="3"
          y1="180"
          x2="200"
          y2="180"
          stroke={COLORS.BLUE_LINE}
          strokeWidth="2"
          strokeLinecap="butt"
        />

        {/* left corner */}
        <rect x="39.02734375" y="13" width="11.9453125" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="45" y="25" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["L Corner"]}
        </text>

        {/* behind net  */}
        <rect x="96.45703125" y="10" width="9.0859375" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="101" y="22" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["Behind the Net"]}
        </text>

        <rect x="154.02734375" y="13" width="11.9453125" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="160" y="25" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["R Corner"]}
        </text>

        <rect x="15.51171875" y="63" width="18.9765625" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="25" y="75" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["Outside L"]}
        </text>

        <text x="58" y="52" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["L Net Side"]}
        </text>

        <text
          x="101"
          y="69"
          textAnchor="middle"
          style={{ fontWeight: 600, fontSize: 10, fill: COLORS.STROKE }}
        >
          {vals["Low Slot"]}
        </text>

        {/* --- CREASE TEXT --- */}
        <rect x="95" y="38" width="13" height="8" fill={COLORS.CREASE} rx="2" />
        <text x="101" y="44" textAnchor="middle" style={{ fontWeight: 600, fontSize: 7 }}>
          {vals["Crease"]}
        </text>

        <text x="145" y="52" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10}}>
          {vals["R Net Side"]}
        </text>

        <rect x="170.40625" y="63" width="19.1875" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="180" y="75" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["Outside R"]}
        </text>

        <rect x="47.3359375" y="93" width="19.328125" height="15" fill={COLORS.RED} rx="2" />
        <text x="57" y="105" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["L Circle"]}
        </text>

        <rect x="92.63671875" y="104" width="16.7265625" height="15" fill={COLORS.RED} rx="2" />
        <text x="101" y="116" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["High Slot"]}
        </text>

        <rect x="135.46484375" y="93" width="19.0703125" height="15" fill={COLORS.RED} rx="2" />
        <text x="145" y="105" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["R Circle"]}
        </text>

        <rect x="18.5" y="146" width="22" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="30" y="155" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["L Point"]}
        </text>

        <rect x="91.875" y="153" width="18.25" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="101" y="165" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["Center Point"]}
        </text>

        <rect x="160.20703125" y="143" width="19.5859375" height="15" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="170" y="155" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10}}>
          {vals["R Point"]}
        </text>

        {/* --- Bottom Badge Area --- */}
        <rect x="92" y="193" width="18" height="14" fill={COLORS.PLAIN_WHITE} rx="2" />
        <text x="101" y="201" textAnchor="middle" style={{ fontWeight: 600, fontSize: 10 }}>
          {vals["Offensive Neutral Zone"]}
        </text>
      </svg>

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: 8,
          opacity: 0.75,
          fontSize: 10,
        }}
      >
        <span>
          Highest Zone: {maxValue} {unitLabel}
        </span>
      </div>
    </div>
  );
}